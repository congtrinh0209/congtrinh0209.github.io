module.exports = {
    NODE_ENV: 'development'
};
